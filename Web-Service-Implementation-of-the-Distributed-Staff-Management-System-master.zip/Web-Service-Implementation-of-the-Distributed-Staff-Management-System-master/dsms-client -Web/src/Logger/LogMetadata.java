package Logger;

public class LogMetadata {
	
	String action;
	String action_requested;
	String response;
	String log_date;
	
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getAction_requested() {
		return action_requested;
	}
	public void setAction_requested(String action_requested) {
		this.action_requested = action_requested;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	public String getLog_date() {
		return log_date;
	}
	public void setLog_date(String log_date) {
		this.log_date = log_date;
	}

}
